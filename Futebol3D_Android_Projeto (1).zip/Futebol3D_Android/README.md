# Futebol 3D para Android

Este projeto empacota o jogo HTML original em um aplicativo Android usando WebView, com orientação horizontal e tela imersiva.

## Gerar o APK no Android Studio
1. Abra a pasta `Futebol3D_Android` no Android Studio.
2. Aguarde a sincronização do Gradle e instale os componentes do Android SDK solicitados.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de depuração ficará normalmente em `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar na nuvem pelo GitHub Actions
O projeto inclui o workflow `.github/workflows/android.yml`.
1. Envie os arquivos desta pasta para um repositório GitHub.
2. Abra a aba **Actions** e selecione **Build Android APK**.
3. Clique em **Run workflow** (ou envie um commit para `main`/`master`).
4. Ao terminar, abra a execução e baixe o artefato `Futebol3D-debug-apk`.

## Observação
O jogo carrega Three.js pela CDN do HTML original, então precisa de internet para baixar essa biblioteca. O APK gerado pelo workflow é um APK de depuração, apropriado para testes e instalação manual, não uma versão assinada para publicação na Play Store.
